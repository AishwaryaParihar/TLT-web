import React from 'react'
import  Registration from "./Registration";
import RegistrationForm from './Registration-form';

 const RegistrationDetails = () => {
  return (
    
    <div className="">
        <div>
          <Registration/>
        </div>

       <div>
        <RegistrationForm/>
       </div>

  
    </div>
  )
}

export default RegistrationDetails;